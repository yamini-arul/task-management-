const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");

const SECRET = process.env.JWT_SECRET || "change-me";
const DB_FILE = "db.json";
const app = express();
app.use(express.json());
app.use(express.static("public"));

const load = () => (fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE)) : { users: [], tasks: [] });
const save = (db) => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
const id = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

// Authentication
app.post("/api/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6)
    return res.status(400).json({ error: "Name, email and a 6+ character password are required" });
  const db = load();
  if (db.users.some((u) => u.email === email.toLowerCase()))
    return res.status(409).json({ error: "Email already registered" });
  const user = { id: id(), name, email: email.toLowerCase(), hash: await bcrypt.hash(password, 10) };
  db.users.push(user);
  save(db);
  res.json({ token: jwt.sign({ id: user.id }, SECRET, { expiresIn: "7d" }), name });
});

app.post("/api/login", async (req, res) => {
  const { email = "", password = "" } = req.body;
  const user = load().users.find((u) => u.email === email.toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.hash)))
    return res.status(401).json({ error: "Invalid email or password" });
  res.json({ token: jwt.sign({ id: user.id }, SECRET, { expiresIn: "7d" }), name: user.name });
});

// Authorization: every task route requires a valid token, and users only see their own tasks
const auth = (req, res, next) => {
  try {
    req.userId = jwt.verify((req.headers.authorization || "").replace("Bearer ", ""), SECRET).id;
    next();
  } catch {
    res.status(401).json({ error: "Please log in" });
  }
};

// CRUD
app.get("/api/tasks", auth, (req, res) => res.json(load().tasks.filter((t) => t.userId === req.userId)));

app.post("/api/tasks", auth, (req, res) => {
  if (!req.body.title?.trim()) return res.status(400).json({ error: "Title is required" });
  const db = load();
  const task = {
    id: id(), userId: req.userId, title: req.body.title.trim(),
    description: req.body.description || "", dueDate: req.body.dueDate || "",
    status: "todo", createdAt: new Date().toISOString(),
  };
  db.tasks.push(task);
  save(db);
  res.status(201).json(task);
});

app.put("/api/tasks/:id", auth, (req, res) => {
  const db = load();
  const task = db.tasks.find((t) => t.id === req.params.id && t.userId === req.userId);
  if (!task) return res.status(404).json({ error: "Task not found" });
  for (const k of ["title", "description", "dueDate", "status"]) if (k in req.body) task[k] = req.body[k];
  save(db);
  res.json(task);
});

app.delete("/api/tasks/:id", auth, (req, res) => {
  const db = load();
  const before = db.tasks.length;
  db.tasks = db.tasks.filter((t) => !(t.id === req.params.id && t.userId === req.userId));
  if (db.tasks.length === before) return res.status(404).json({ error: "Task not found" });
  save(db);
  res.status(204).end();
});

app.listen(process.env.PORT || 3000, () => console.log("Running on http://localhost:3000"));
